/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: "class",
  content: [
    "./app/**/*.{js,jsx,ts,tsx}",
    "./src/**/*.{js,jsx,ts,tsx}",
    "./components/**/*.{js,jsx,ts,tsx}",
  ],
  presets: [require("nativewind/preset")],
  theme: {
    extend: {
      colors: {
        bg: {
          canvas: "rgb(var(--bg-canvas) / <alpha-value>)",
          surface: "rgb(var(--bg-surface) / <alpha-value>)",
          elevated: "rgb(var(--bg-elevated) / <alpha-value>)",
          subtle: "rgb(var(--bg-subtle) / <alpha-value>)",
        },
        text: {
          primary: "rgb(var(--text-primary) / <alpha-value>)",
          secondary: "rgb(var(--text-secondary) / <alpha-value>)",
          muted: "rgb(var(--text-muted) / <alpha-value>)",
          onBrand: "rgb(var(--text-on-brand) / <alpha-value>)",
        },
        border: {
          subtle: "rgb(var(--border-subtle) / <alpha-value>)",
          strong: "rgb(var(--border-strong) / <alpha-value>)",
        },
        brand: {
          DEFAULT: "rgb(var(--brand-primary) / <alpha-value>)",
          pressed: "rgb(var(--brand-primary-pressed) / <alpha-value>)",
          soft: "rgb(var(--brand-soft) / <alpha-value>)",
        },
        finance: {
          vital: "rgb(var(--finance-vital) / <alpha-value>)",
          vitalSoft: "rgb(var(--finance-vital-soft) / <alpha-value>)",
          growth: "rgb(var(--finance-growth) / <alpha-value>)",
          growthSoft: "rgb(var(--finance-growth-soft) / <alpha-value>)",
          warning: "rgb(var(--finance-warning) / <alpha-value>)",
          warningSoft: "rgb(var(--finance-warning-soft) / <alpha-value>)",
          danger: "rgb(var(--finance-danger) / <alpha-value>)",
          dangerSoft: "rgb(var(--finance-danger-soft) / <alpha-value>)",
        },
      },
      fontFamily: {
        sans: ["PlusJakartaSans_400Regular", "System"],
        "sans-medium": ["PlusJakartaSans_500Medium", "System"],
        "sans-semibold": ["PlusJakartaSans_600SemiBold", "System"],
        "sans-bold": ["PlusJakartaSans_700Bold", "System"],
        "sans-extrabold": ["PlusJakartaSans_800ExtraBold", "System"],
        mono: ["JetBrainsMono_600SemiBold", "monospace"],
        "mono-bold": ["JetBrainsMono_700Bold", "monospace"],
      },
      borderRadius: {
        xs: "8px",
        sm: "12px",
        md: "16px",
        lg: "20px",
        xl: "24px",
      },
      spacing: {
        touch: "48px", // Mínimo ergonómico Android (48x48dp)
        fab: "54px",
      },
    },
  },
  plugins: [],
};
